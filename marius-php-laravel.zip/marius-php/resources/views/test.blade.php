@extends('layouts.app')

@section('content')
    <div>
        {{dd($test)}}
    </div>
@endsection