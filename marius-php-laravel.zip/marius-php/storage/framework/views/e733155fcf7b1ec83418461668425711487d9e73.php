<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="h1-responsive font-weight-bold text-center m-4 border-bottom ">SVEIKI ATVYKĘ!</h1>
    </div>
    <div><h3 class="h1-responsive font-weight-bold text-center m-4 ">Aktyvūs renginiai:</h3></div>
    <div class="container d-flex flex-wrap">
        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="flex card m-3" style="width: 18rem;">
                <img src="<?php echo e(url('storage'.$item->image)); ?>" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($item->title); ?></h5>
                        <p class="card-text"><?php echo e($item->description); ?></p>
                        <a href="/event/<?php echo e($item->id); ?>" class="btn btn-danger">Eiti į Renginį</a>
                    </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <footer class="py-3 my-4 fixed-bottom">
            <ul class="nav justify-content-center border-bottom pb-3 mb-3"></ul>
            <p class="text-center text-muted">© 2022 KITM</p>
        </footer>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\marius-php\resources\views/events/events.blade.php ENDPATH**/ ?>