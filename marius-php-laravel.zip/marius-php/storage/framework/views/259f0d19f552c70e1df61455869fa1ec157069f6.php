<?php $__env->startSection('content'); ?>

    <div class="container">
        <h2 class="h1-responsive font-weight-bold text-center my-4">Daugiau apie mus</h2>
        <p class="text-center w-responsive mx-auto mb-5 h5"> Šiuo metu mokykloje mokosi daugiau kaip 500 mokinių. Jie mokosi kompiuterio ir organizacinės technikos operatoriaus, multimedijos paslaugų teikėjo, kompiuterių tinklų derintojo, žiniatinklio programuotojo, mobiliosios elektronikos taisytojo, apskaitininko ir kasininko, bankinių operacijų tvarkytojo, sekretoriaus specialybių.<br><br>
         Pirmuoju mokyklos direktoriumi buvo F. Aleksejev ( 1945 11 – 1947 02 ).<br>
         Nuo 1990 rugsėjo mėn. mokyklos direktoriumi dirba J. Dambrauskas.<br><br>
         Mokykla įsikūrusi dviejuose pastatuose Laisvės al. 33 ir Kęstučio g. 53.</p>
    </div>
    <footer class="py-3 my-4 fixed-bottom">
    <ul class="nav justify-content-center border-bottom pb-3 mb-3"></ul>
    <p class="text-center text-muted">© 2022 KITM</p>
  </footer>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\marius-php\resources\views/aboutus.blade.php ENDPATH**/ ?>