<?php $__env->startSection('content'); ?>

    <div class="container d-flex">
        <div class="card" style="width: 18rem;">
            <img src="..." class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($event->title); ?></h5>
                    <p class="card-text"><?php echo e($event->description); ?></p>
                </div>
        </div>
    </div>

    <div class="container">
        <form action="/register/event" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" id="event_id" name="event_id" value="<?php echo e($event->id); ?>">
            <div class="form-group">
                <label for="name">Vardas</label>
                <input name="name" id="name" class="form-control">
            </div>
            <div class="form-group">
                <label for="email">El. Paštas</label>
                <input type="text" id="email" name="email" class="form-control">
            </div>
            <div class="form-group">
                <label for="telephone">Telefonas</label>
                <input type="text" id="telephone" name="telephone" class="form-control">
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit" id="button-1">Siūsti</button>
            </div>
        </form>
    </div>

    <div class="container">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Vardas</th>
                    <th scope="col">El. Paštas</th>
                    <th scope="col">Telefonas</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $event->eventUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($item->event_id); ?></th>
                    <td><?php echo e($item->name); ?></td>
                    <td><?php echo e($item->email); ?></td>
                    <td><?php echo e($item->telephone); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <footer class="py-3 my-4 fixed-bottom">
            <ul class="nav justify-content-center border-bottom pb-3 mb-3"></ul>
            <p class="text-center text-muted">© 2022 KITM</p>
        </footer>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\marius-php\resources\views/events/event.blade.php ENDPATH**/ ?>